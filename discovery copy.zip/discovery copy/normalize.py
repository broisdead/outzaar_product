"""Normalization: raw provider item -> comparable company record. Never rejects for missing fields."""
from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass

from .geo import canonical_city, canonical_state, detect_locations, state_of
from .providers.base import RawItem

# Domains that are aggregators / directories / social / media, NOT a company's own site.
# A result on one of these never yields a company "domain".
NON_COMPANY_DOMAINS = {
    # Tech & Startup directories / listings
    "f6s.com", "beststartup.asia", "beststartup.in", "beststartup.co.uk",
    "getlatka.com", "latka.com", "wellfound.com", "angel.co",
    "tracxn.com", "crunchbase.com", "clutch.co", "goodfirms.co",
    "softwaresuggest.com", "g2.com", "capterra.com", "producthunt.com",
    "saashub.com", "alternativeto.net", "trustradius.com", "peerspot.com",
    "startuptalky.com", "failory.com", "topstartups.io", "pitchbook.com",
    "cbinsights.com", "apollo.io", "rocketreach.co", "lusha.com",
    "zoominfo.com", "dnb.com", "kompass.com", "dealroom.co",
    "ventureslist.com", "startupranking.com",

    # Media, blogs, publishers, social
    "inc42.com", "yourstory.com", "entrackr.com", "medianama.com",
    "techinasia.com", "techcrunch.com", "venturebeat.com", "forbes.com",
    "business-standard.com", "economictimes.com", "moneycontrol.com",
    "livemint.com", "hindubusinessline.com", "timesofindia.com", "ndtv.com",
    "medium.com", "substack.com", "wordpress.com", "blogspot.com",
    "linkedin.com", "facebook.com", "instagram.com", "twitter.com", "x.com",
    "youtube.com", "pinterest.com", "reddit.com", "quora.com",
    "wikipedia.org", "wikimedia.org", "github.com",

    # B2B Trade directories & Aggregators
    "indiamart.com", "tradeindia.com", "exportersindia.com", "justdial.com",
    "sulekha.com", "yellowpages.in", "asklaila.com", "made-in-china.com",
    "alibaba.com", "aliexpress.com", "amazon.in", "amazon.com", "flipkart.com",
    "zaubacorp.com", "tofler.in", "instafinancials.com", "thecompanycheck.com",
    "tradeindia.in",

    # Job boards & search engines
    "glassdoor.com", "glassdoor.co.in", "ambitionbox.com", "naukri.com",
    "indeed.com", "google.com", "google.co.in", "bing.com", "yahoo.com",
    "duckduckgo.com", "mapquest.com",

    # Govt & Trade Associations
    "gov.in", "nic.in", "mca.gov.in", "fieo.org", "cii.in", "ficci.in",
    "eepcindia.org", "nasscom.in", "assocham.org",
}

LEGAL_SUFFIXES = {
    "pvt", "private", "ltd", "limited", "llp", "inc", "incorporated", "co", "company",
    "corp", "corporation", "opc", "p", "the",
}
GENERIC_SEGMENTS = {
    "home", "homepage", "welcome", "contact us", "about us", "about", "official website",
    "official site", "products", "services", "index", "linkedin", "facebook", "f6s",
    "wellfound", "crunchbase", "clutch", "getlatka", "latka", "beststartup", "tracxn",
}
LISTING_HINT = re.compile(
    r"\b(top\s+\d+|best\s+\d+|\d+\s+(?:best|top|leading)|list\s+of|directory|companies\s+in|"
    r"startups\s+in|manufacturers\s+in|suppliers\s+in|exporters\s+in|leading\s+\w+\s+in|"
    r"\d{1,3}\+?\s+(?:best|top|leading)"
    # Catches "Top B2B SaaS Companies", "Best SaaS Companies", "Leading Startups", etc.
    r"|(?:top|best|leading|top-rated)\s+\w[\w\s]*?\s+(?:companies|startups|firms|vendors|providers|manufacturers|suppliers|exporters)"
    r")\b", re.I)
COMPANY_SUFFIX = re.compile(
    r"\b(pvt\.?|private|ltd\.?|limited|llp|industries|enterprises|exports?|engineering|"
    r"mfg|manufacturing|technologies|systems|corporation|works|fabricators|products|software|"
    r"solutions|labs|tech|ai|analytics|robotics)\b", re.I)
SEPARATORS = re.compile(r"\s+[-–—|:•»·]\s+|\s*\|\s*")


def extract_domain(url: str) -> str:
    """Registrable-ish domain ('shop.abc.co.in' -> 'abc.co.in'). '' if none."""
    if not url:
        return ""
    u = url.strip()
    if "://" not in u:
        u = "http://" + u
    try:
        host = (urllib.parse.urlparse(u).hostname or "").lower().strip(".")
    except ValueError:
        return ""
    if host.startswith("www."):
        host = host[4:]
    if not host or "." not in host:
        return ""
    labels = host.split(".")
    if len(labels) >= 3 and labels[-2] in {"co", "com", "org", "net", "ac", "gov", "edu", "nic", "res"} and len(labels[-1]) == 2:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def is_company_domain(domain: str) -> bool:
    if not domain:
        return False
    return not any(domain == d or domain.endswith("." + d) for d in NON_COMPANY_DOMAINS)


def normalize_name(name: str) -> str:
    n = (name or "").lower().replace("&", " and ")
    n = re.sub(r"[^a-z0-9 ]+", " ", n)
    toks = [t for t in n.split() if t]
    core = [t for t in toks if t not in LEGAL_SUFFIXES]
    return " ".join(core or toks)


def name_from_title(title: str, domain: str = "") -> str:
    """Pull a company-looking name out of a page/search title."""
    t = re.sub(r"\s+", " ", (title or "")).strip()
    if not t:
        return domain.split(".")[0].replace("-", " ").title() if domain else ""
    segs = [s.strip() for s in SEPARATORS.split(t) if s.strip()]
    segs = [s for s in segs if s.lower() not in GENERIC_SEGMENTS] or segs
    for s in segs:                       # prefer a segment that looks like a company name
        if COMPANY_SUFFIX.search(s) and len(s) <= 80:
            return s
    first = segs[0] if segs else t
    if len(first) > 80 and domain:
        return domain.split(".")[0].replace("-", " ").title()
    return first[:120]


@dataclass
class NormalizedItem:
    name: str
    name_norm: str
    domain: str
    website: str
    city: str
    state: str
    city_norm: str
    state_norm: str
    phone: str
    address: str
    description: str
    source_id: str
    source_url: str
    is_listing: bool = False
    note: str = ""

    @property
    def resolvable(self) -> bool:
        """Identifiable enough to become a company record: needs a name or a domain."""
        return bool(self.name_norm or self.domain) and not self.is_listing


def normalize(item: RawItem) -> NormalizedItem:
    raw_website = (item.website or "").strip()
    raw_source = (item.source_url or "").strip()
    domain = extract_domain(raw_website)
    
    # If the domain is an aggregator / directory, clear domain so directory is never saved as company domain
    if not is_company_domain(domain):
        domain, website = "", ""
    elif raw_website and "://" not in raw_website:
        website = "https://" + raw_website
    else:
        website = raw_website

    name = (item.name or "").strip()
    if not name and item.title:
        name = name_from_title(item.title, domain)
    first_seg = (SEPARATORS.split(item.title.strip())[0] if item.title else "")
    
    # Detect listing/article page from title, domain, or URL path
    path = urllib.parse.urlparse(raw_source or raw_website).path.lower()
    is_listing_path = any(s in path for s in ("/top-", "/best-", "/companies-in-", "/startups-in-", "/list-of-", "/directory/"))
    # Check both the title (when no explicit name) AND the name itself:
    # A RawItem with name="Top B2B SaaS Companies" must also be flagged as a listing.
    _listing_candidate = first_seg or item.title or ""
    is_listing = bool(
        (
            # Title-derived listing detection (original logic, no explicit name)
            not item.name and (
                (_listing_candidate and LISTING_HINT.search(_listing_candidate) and not COMPANY_SUFFIX.search(first_seg))
                or is_listing_path
            )
        ) or (
            # Name-based listing detection: catches names like "Top B2B SaaS Companies"
            item.name and LISTING_HINT.search(item.name) and not COMPANY_SUFFIX.search(item.name)
        )
    )

    city = canonical_city(item.city)
    state = canonical_state(item.state)
    if not city and not state:
        c, s = detect_locations(item.address or "")
        if not (c or s):
            c, s = detect_locations(item.location_hint or "")
        if not (c or s):
            c, s = detect_locations(item.title or "")
        city, state = c, s
    if city and not state:
        state = state_of(city)

    return NormalizedItem(
        name=name, name_norm=normalize_name(name), domain=domain, website=website,
        city=city, state=state, city_norm=city.lower(), state_norm=state.lower(),
        phone=(item.phone or "").strip(), address=(item.address or "").strip(),
        description=(item.description or "").strip()[:1000],
        source_id=(item.source_id or "").strip(), source_url=raw_source or raw_website,
        is_listing=is_listing,
        note="listing/article page, not a single company" if is_listing else "",
    )
